import sys
import plotly.graph_objects as go
import os
import numpy as np
import argparse

# Arguments
parser = argparse.ArgumentParser(description="Run temperature graph generator.")


parser.add_argument("--path", "-p", type=str, required=True, help="folder of data")


def main(args):
    path=args.path
    dict_time_per_n_iteration = {}
    dict_total_time = {}
    fig_total_training_time = go.Figure()
    for r, d, f in os.walk(path):
        for directory in d:
            print(directory)
            dict_time_per_n_iteration[directory] = 0
            temp_list_training_each_round = []
            new_path = path + "/" + directory
            for r1, d1, f1 in os.walk(new_path):
                for ff in f1:    
                    if "round_testing" in ff:
                        # Dictionary for total training time
                        key_dict_total_time =  ff.split("_")[0]
                        if not key_dict_total_time in dict_total_time.keys():
                            dict_total_time[key_dict_total_time] = []
                        print(ff)
                        to_read = open(new_path + "/" + ff, "r")
                        lines = to_read.readlines()
                        temp_list_total_training = []
                        for line in lines:
                            if "Time round" in line:
                                time_each_round = float(line.split(" : ")[1].rstrip())
                                temp_list_training_each_round.append(time_each_round)
                            if "Total training time" in line:
                                total_training_time = float(line.split(": ")[1].rstrip())
                                temp_list_total_training.append(total_training_time)
                        dict_total_time[key_dict_total_time].append(np.round(np.average(temp_list_total_training), decimals=3))
                        to_read.close()
            dict_time_per_n_iteration[directory] = np.round(np.average(temp_list_training_each_round), decimals=3)
    
    print(dict_total_time)
    print(dict_time_per_n_iteration)
    x = []
    y = []
    texts = []
    for key in dict_time_per_n_iteration.keys():
        x.append(key)
        y.append(dict_time_per_n_iteration[key])
        texts.append('<b>' + str(dict_time_per_n_iteration[key]) + '</b>')
    
    # Total training time trace
    temp_x = x.copy()
    list.sort(temp_x)
    for key in dict_total_time.keys():
        list.sort(dict_total_time[key])
        fig_total_training_time.add_trace(go.Bar(x=temp_x, y=dict_total_time[key], text=dict_total_time[key], name=key, textposition='outside'))
    

    fig_training_time_each_round = go.Figure(data=[go.Bar(
            x=x, y=y,
            text=texts,
            textposition='outside',
        )])
    # Customize aspect
    fig_training_time_each_round.update_traces(
        marker_color='#33c7ff', 
        marker_line_color='#3390FF',
        marker_line_width=2, opacity=0.7,
        textfont=dict(
        family="Courier New, monospace",
        size=16,
        color="black"
    ))

    fig_training_time_each_round.update_layout(
        xaxis_title='iterations',
        yaxis_title='Time',
    )
    fig_total_training_time.update_layout(
        xaxis_title='iterations',
        yaxis_title='Time',
    )
    name="test"
    fig_training_time_each_round.write_image("./images/" + name + ".pdf", width=720, height=600)                            
    # fig_training_time_each_round.show()
    # name="total_time_average"
    # fig_total_training_time.write_image("./images/" + name + ".pdf")
    # fig_total_training_time.show()

if __name__ == "__main__":
    args = parser.parse_args()
    main(args)