import sys
import plotly.graph_objects as go
import os
import numpy as np
from datetime import datetime
import statistics

# COMMAND TO GENERATE THE GRAPHS
# python network_graph.py -p "./" -st1 12:13:05 -et1 12:13:32 -st2 12:34:07 -et2 12:34:34 -st3 12:45:38 -et3 12:46:05 -r 1
# python network_graph.py -p "./" -st1 12:13:05 -et1 12:13:32 -st2 12:34:07 -et2 12:34:34 -st3 12:45:38 -et3 12:46:05 -r 1 -i
# python network_graph.py -p "./" -st1 14:11:37 -et1 14:12:30 -st2 14:26:51 -et2 14:27:44 -st3 14:44:56 -et3 14:45:49 -r 2
# python network_graph.py -p "./" -st1 14:11:37 -et1 14:12:30 -st2 14:26:51 -et2 14:27:44 -st3 14:44:56 -et3 14:45:49 -r 2 -i
# python network_graph.py -p "./" -st1 14:57:05 -et1 15:11:22 -st2 15:09:06 -et2 15:11:13 -st3 15:21:57 -et3 15:23:43 -r 3
# python network_graph.py -p "./" -st1 14:57:05 -et1 15:11:22 -st2 15:09:06 -et2 15:11:13 -st3 15:21:57 -et3 15:23:43 -r 3 -i

import argparse
# Arguments
parser = argparse.ArgumentParser(description="Run websocket server worker.")
parser.add_argument(
    "--path", "-p", type=str, required=True, help="folder of data"
)
parser.add_argument("-st1", "--stime1", type=str, required=True, help="represents the training start time of the first test hh:mm:ss")
parser.add_argument("-et1", "--etime1",type=str, required=True, help="represents the training end time of the first test hh:mm:ss")

parser.add_argument("-st2", "--stime2",type=str, required=True, help="represents the training start time of the second test hh:mm:ss")
parser.add_argument("-et2", "--etime2",type=str, required=True, help="represents the training end time of the second test hh:mm:ss")

parser.add_argument("-st3", "--stime3",type=str, required=True, help="represents the training start time of the third test hh:mm:ss")
parser.add_argument("-et3", "--etime3",type=str, required=True, help="represents the training end time of the third test hh:mm:ss")

parser.add_argument("-r", "--round", type=str, required=True, help="Test for number of round. Matching of parameters: 1 => 3 rounds, 2 => 6 rounds, 3 => 12 rounds")
parser.add_argument("-i", "--incoming",  action='store_true', help="Activate the generation of the incoming traffic for the devices (by default is outgoing)")


def main(args):
    path=args.path
    dict_outgoing = {} # Values for each file
    dict_outgoing_directory = {} # average of file's values for each directory
    for r, d, f in os.walk(path):
        for directory in d:
            new_path = path + "/" + directory
            dict_outgoing_directory[directory] = []
            print("##########DIRECTORY: " + directory)
            # In this case we consider only the network files!
            for r1, d1, f1 in os.walk(new_path):
                # we are in the correct dire
                # So for each file in the dire
                for ff in f1:
                    if "monitoring_network" in ff and ff.endswith((args.round + ".txt")):
                        # File monitor_network
                        # Now, they are dived in round (1=3round, 2=6round, 3=7round)
                        dict_outgoing[ff] = [] # Dictionary of outgoing values for each file
                        print(ff)
                        to_read = open(new_path + "/" + ff, "r")
                        lines = to_read.readlines()
                        i = 0
                        valid = 0
                        actual_time = 0
                        valid_time = False
                        for line in lines:
                            if i%4 == 0:
                                # print("First line: " + str(line))
                                date = line.split(": ")[1].split(" ")[1]
                                hour = line.split(": ")[1].split(" ")[2]
                                # datetime(year, month, day, hour, minute, second, microsecond)
                                actual_date = datetime(int(date.split("-")[0]), int(date.split("-")[1]), int(date.split("-")[2]), int(hour.split(":")[0]), int(hour.split(":")[1]),int(hour.split(":")[2].split(".")[0]))
                                
                                # Interval definition
                                training_time_start_1 = datetime.timestamp(datetime(int(date.split("-")[0]), int(date.split("-")[1]), int(date.split("-")[2]), int(args.stime1.split(":")[0]), int(args.stime1.split(":")[1]), int(args.stime1.split(":")[2])-3))
                                training_time_end_1 = datetime.timestamp(datetime(int(date.split("-")[0]), int(date.split("-")[1]), int(date.split("-")[2]), int(args.etime1.split(":")[0]), int(args.etime1.split(":")[1]), int(args.etime1.split(":")[2])+3))
                                training_time_start_2 = datetime.timestamp(datetime(int(date.split("-")[0]), int(date.split("-")[1]), int(date.split("-")[2]), int(args.stime2.split(":")[0]), int(args.stime2.split(":")[1]), int(args.stime2.split(":")[2])-3))
                                training_time_end_2 = datetime.timestamp(datetime(int(date.split("-")[0]), int(date.split("-")[1]), int(date.split("-")[2]), int(args.etime2.split(":")[0]), int(args.etime2.split(":")[1]), int(args.etime2.split(":")[2])+3))
                                training_time_start_3 = datetime.timestamp(datetime(int(date.split("-")[0]), int(date.split("-")[1]), int(date.split("-")[2]), int(args.stime3.split(":")[0]), int(args.stime3.split(":")[1]), int(args.stime3.split(":")[2])-3))
                                training_time_end_3 = datetime.timestamp(datetime(int(date.split("-")[0]), int(date.split("-")[1]), int(date.split("-")[2]), int(args.etime3.split(":")[0]), int(args.etime3.split(":")[1]), int(args.etime3.split(":")[2])+3))
                                
                                # Monitor time
                                actual_time = datetime.timestamp(actual_date)

                                #print(actual_time)
                                
                                if (actual_time <= training_time_end_1 and actual_time >= training_time_start_1) or (actual_time <= training_time_end_2 and actual_time >= training_time_start_2) or (actual_time <= training_time_end_3 and actual_time >= training_time_start_3):
                                    valid_time = True
                                    # dict_outgoing[directory].append(actual_date)
                                    valid += 1
                            elif i%4 == 1:
                                if valid_time and args.incoming:
                                    
                                    traffic = line.split(": ")[1].split("=")[1].split(",")[0]
                                    
                                    if "K" in traffic:
                                        traffic = float(traffic.replace("K", ""))
                                    elif "B" in traffic:
                                        traffic = float(traffic.replace("B", ""))/1000 # In decimal
                                        
                                    dict_outgoing[ff].append(traffic)
                            elif i%4 == 2:
                                if valid_time and not args.incoming:
                    
                                    traffic = line.split(": ")[1].split("=")[1].split(",")[0]
                                    
                                    if "K" in traffic:
                                        traffic = float(traffic.replace("K", ""))
                                    elif "B" in traffic:
                                        traffic = float(traffic.replace("B", ""))/1000 # In decimal
                                        
                                    dict_outgoing[ff].append(traffic)
                                   
                            
                            elif i%4 == 3:
                                valid_time = False
                                # print("Discard")
                                #print()
                            else:
                                print("no valid")
                            i += 1
                        # print(valid)
                print(dict_outgoing)
            
            # Here we change directory so we need to compute the average
            temp_list = []
            # Create a list of list for zip
            for key in dict_outgoing.keys():
                temp_list.append(dict_outgoing[key].copy())
            # Create zip
            zipped_list = zip(*temp_list)
            dict_outgoing_directory[directory] = [np.around(statistics.mean(k), decimals=2) for k in zipped_list]
            
            print(dict_outgoing_directory)
    
    
    fig = go.Figure()
    for key in dict_outgoing_directory.keys():
        fig.add_trace(go.Scatter(mode='lines+markers', x=list(range(0,len(dict_outgoing_directory[key]))), y=dict_outgoing_directory[key], name=(str(key))))
    
    fig.update_traces(textposition='bottom right')
    # Edit the layout
    fig.update_layout(title='',
                    xaxis_title='Time',
                    yaxis_title='Bandwidth(Kbyte)',
                    showlegend=True,)
    
    name = "bandwidth_3round_outgoing"
    fig.write_image("../../images/" + name + ".pdf", width=1920, height=1080)

    fig.show()           
if __name__ == "__main__":
    args = parser.parse_args()
    main(args)