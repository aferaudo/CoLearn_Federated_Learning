import sys
import plotly.graph_objects as go
import os
import numpy as np
from datetime import datetime
import statistics

# COMMAND TO GENERATE THE GRAPHS
# python network_graph.py -p "./" -st1 19:08:04 -et1 19:09:01 -st2 19:19:26 -et2 19:20:22 -st3 19:29:59 -et3 19:30:56 -r 1
# python network_graph.py -p "./" -st1 19:08:04 -et1 19:09:01 -st2 19:19:26 -et2 19:20:22 -st3 19:29:59 -et3 19:30:56 -r 1 -i
# python network_graph.py -p "./" -st1 19:43:59 -et1 19:45:52 -st2 20:10:08 -et2 20:12:01 -st3 9:24:06 -et3 9:26:17 -r 2
# python network_graph.py -p "./" -st1 19:43:59 -et1 19:45:52 -st2 20:10:08 -et2 20:12:01 -st3 9:24:06 -et3 9:26:17 -r 2 -i

import argparse
# Arguments
parser = argparse.ArgumentParser(description="Run websocket server worker.")
parser.add_argument(
    "--path", "-p", type=str, required=True, help="folder of data"
)
parser.add_argument("-st1", "--stime1", type=str, required=True, help="represents the training start time of the first test hh:mm:ss")
parser.add_argument("-et1", "--etime1",type=str, required=True, help="represents the training end time of the first test hh:mm:ss")

parser.add_argument("-i", "--incoming",  action='store_true', help="Activate the generation of the incoming traffic for the devices (by default is outgoing)")


def main(args):
    path=args.path
    dict_outgoing = {} # Values for each file
    dict_outgoing_directory = {} # average of file's values for each directory
    for r, d, f in os.walk(path):
        for directory in d:
            new_path = path + "/" + directory
            dict_outgoing_directory[directory] = []
            print("##########DIRECTORY: " + directory)
            # In this case we consider only the network files!
            for r1, d1, f1 in os.walk(new_path):
                # we are in the correct dire
                # So for each file in the dire
                for ff in f1:
                    if "monitoring_network" in ff:
                        # File monitor_network
                        # Now, they are dived in round (1=3round, 2=6round, 3=7round)
                        dict_outgoing[ff] = [] # Dictionary of outgoing values for each file
                        print(ff)
                        to_read = open(new_path + "/" + ff, "r")
                        lines = to_read.readlines()
                        i = 0
                        valid = 0
                        actual_time = 0
                        valid_time = False
                        for line in lines:
                            if i%4 == 0:
                                # print("First line: " + str(line))
                                date = line.split(": ")[1].split(" ")[1]
                                hour = line.split(": ")[1].split(" ")[2]
                                # datetime(year, month, day, hour, minute, second, microsecond)
                                actual_date = datetime(int(date.split("-")[0]), int(date.split("-")[1]), int(date.split("-")[2]), int(hour.split(":")[0]), int(hour.split(":")[1]),int(hour.split(":")[2].split(".")[0]))
                                
                                # Interval definition
                                training_time_start_1 = datetime.timestamp(datetime(int(date.split("-")[0]), int(date.split("-")[1]), int(date.split("-")[2]), int(args.stime1.split(":")[0]), int(args.stime1.split(":")[1]), int(args.stime1.split(":")[2])-3))
                                training_time_end_1 = datetime.timestamp(datetime(int(date.split("-")[0]), int(date.split("-")[1]), int(date.split("-")[2]), int(args.etime1.split(":")[0]), int(args.etime1.split(":")[1]), int(args.etime1.split(":")[2])+3))
                                
                                # Monitor time
                                actual_time = datetime.timestamp(actual_date)

                                #print(actual_time)
                                
                                if actual_time <= training_time_end_1 and actual_time >= training_time_start_1:
                                    valid_time = True
                                    # dict_outgoing[directory].append(actual_date)
                                    valid += 1
                            elif i%4 == 1:
                                if valid_time and args.incoming:
                                    
                                    traffic = line.split(": ")[1].split("=")[1].split(",")[0]
                                    
                                    if "K" in traffic:
                                        traffic = float(traffic.replace("K", ""))
                                    elif "B" in traffic:
                                        traffic = float(traffic.replace("B", ""))/1000 # In decimal
                                    elif "M" in traffic:
                                        traffic = float(traffic.replace("M", ""))*1000 # In decimal
                                        
                                    dict_outgoing[ff].append(traffic)
                            elif i%4 == 2:
                                if valid_time and not args.incoming:
                    
                                    traffic = line.split(": ")[1].split("=")[1].split(",")[0]
                                    
                                    if "K" in traffic:
                                        traffic = float(traffic.replace("K", ""))
                                    elif "B" in traffic:
                                        traffic = float(traffic.replace("B", ""))/1000 # In decimal
                                    elif "M" in traffic:
                                        traffic = float(traffic.replace("M", ""))*1000 # In decimal
                                    dict_outgoing[ff].append(traffic)
                                   
                            
                            elif i%4 == 3:
                                valid_time = False
                                # print("Discard")
                                #print()
                            else:
                                print("no valid")
                            i += 1
                        # print(valid)
                print(dict_outgoing)
            
            # Here we change directory so we need to compute the average
            temp_list = []
            # Create a list of list for zip
            for key in dict_outgoing.keys():
                temp_list.append(dict_outgoing[key].copy())
            # Create zip
            zipped_list = zip(*temp_list)
            dict_outgoing_directory[directory] = [np.around(statistics.mean(k), decimals=2) for k in zipped_list]
            
            print(dict_outgoing_directory)
    
    
    fig = go.Figure()
    
    
    fig.update_traces(textposition='bottom right')
    # Edit the layout
    fig.update_layout(title='',
                    xaxis_title='Time',
                    yaxis_title='Bandwidth(Kbyte)',
                    showlegend=True,)
    
    

    fig.show()           
if __name__ == "__main__":
    args = parser.parse_args()
    main(args)