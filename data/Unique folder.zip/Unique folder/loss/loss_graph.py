import sys
import plotly.graph_objects as go
import os
import numpy as np
import argparse

# Arguments
parser = argparse.ArgumentParser(description="Run temperature graph generator.")


parser.add_argument("--path", "-p", type=str, required=True, help="folder of data")


def main(args):
    path=args.path
    dict_losses_per_iteration = {}
    x = []
    for r, d, f in os.walk(path):
        for directory in d:
            print(directory)
            new_path = path + "/" + directory
            for r1, d1, f1 in os.walk(new_path):
                for ff in f1:
                    if "round_testing" in ff:
                        print(ff)
                        
                        key_dict_losses = ff.split("_")[0]
                        if not key_dict_losses in dict_losses_per_iteration.keys():
                            dict_losses_per_iteration[key_dict_losses] = []
                    
                        to_read = open(new_path + "/" + ff, "r")
                        lines = to_read.readlines()
                        temp_losses = [] # useful to compute the averages of the losses

                        for line in lines:
                            if "Loss evaluation" in line:
                                loss = float(line.split(": ")[1].rstrip())
                                temp_losses.append(loss)
                        
                        # Add the losses in the dictionary
                        dict_losses_per_iteration[key_dict_losses].append(np.round(np.average(temp_losses), decimals=6))
                        list.sort(dict_losses_per_iteration[key_dict_losses], reverse=True) # Sort the list
            
                        # Closing file
                        to_read.close()

            x.append(int(directory.split("_")[0]))
    
    list.sort(x)
    print(dict_losses_per_iteration)
    print(x)

    fig = go.Figure()
    for key in dict_losses_per_iteration.keys():
        fig.add_trace(go.Bar(x=x, y=dict_losses_per_iteration[key], text=dict_losses_per_iteration[key], textposition='outside', name=key))

    fig.update_layout(
        xaxis_title='Rounds',
        yaxis_title='Losses',
    )

    name="loss_organized_per_round"
    fig.write_image("./images/" + name + ".pdf")
    fig.show()

if __name__ == "__main__":
    args = parser.parse_args()
    main(args)