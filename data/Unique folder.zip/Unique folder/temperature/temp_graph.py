import sys
import plotly.graph_objects as go
import os
import numpy as np
import argparse
from datetime import datetime
import statistics
# Arguments
parser = argparse.ArgumentParser(description="Run temperature graph generator.")

parser.add_argument("--path", "-p", type=str, required=True, help="folder of data")

parser.add_argument('-s','--stime', nargs='+', help="List of training start times: the interval is considered as the index matching (e.g. [stime_1 e_time_1], [stime_2, end_time2 ]...)")
parser.add_argument('-e','--etime', nargs='+', help="List of training end times (in this are considered 3 test! So, no more than three tests for each max number of iteration)")

# Command to execute to generate the graphs
# 3 ROUNDS: python temp_graph.py -p ./3Round --stime 12:13:05 12:34:07 12:45:38 17:49:39 18:01:56 18:14:25 19:08:05 19:19:26 19:29:59 --etime 12:13:32 12:34:34 12:46:05 17:50:17 18:02:34 18:15:03 19:09:01 19:20:22 19:30:54
# 6 ROUNDS: python temp_graph.py -p ./6Round --stime 14:11:37 14:26:51 14:44:56 18:29:40 18:43:55 18:55:14 19:43:59 20:10:08 9:24:06 --etime 14:12:30 14:27:44 14:45:49 18:30:54 18:45:12 18:56:30 19:45:52 20:12:01 9:26:27
# 12 ROUNDS: (In this case we have only the 1000 iterations case) python temp_graph.py -p ./12Round --stime 14:57:05 15:09:36 15:21:57 --etime 14:58:51 15:11:22 15:23:43
# NO ROUND: python temp_graph.py -p ./733672_items --stime 15:35:44 --etime 16:52:53
def main(args):
    path=args.path
    # print(list_start_time)
    # print(list_end_time)
    fig_pi1 = go.Figure()
    fig_pi2 = go.Figure()

    for r, d, f in os.walk(path):
        for directory in d:
            print(directory)
            new_path = path + "/" + directory
            for r1, d1, f1 in os.walk(new_path):
                # we are in the correct dire
                # So for each file in the dir

                
                dict_files = {}
                
                for ff in f1:
                    if "monitoring_temp" in ff:
                        dict_files[ff] = []
                        print(ff)
                        to_read = open(new_path + "/" + ff, "r")
                        lines = to_read.readlines()
                        i = 0
                        list_start_time = []
                        list_end_time = []
                        d_time = False
                        valid_time = False
                        # f = open("testing.txt", "w+")
                        for line in lines:
                            
                            if i % 2 == 0:
                                # print(line)
                                date = line.split(" : ")[1].split(" ")[0]
                                # print(date)
                                hour = line.split(" : ")[1].split(" ")[1]

                                # datetime(year, month, day, hour, minute, second, microsecond)
                                actual_date = datetime(int(date.split("-")[0]), int(date.split("-")[1]), int(date.split("-")[2]), int(hour.split(":")[0]), int(hour.split(":")[1]),int(hour.split(":")[2].split(".")[0]))
                                

                                # Define the interval of interest (5 second before start traing and 5 second after training)
                                if not d_time: # Only one time for each file
                                    d_time = True
                                    for stime in args.stime:
                                        t_start_time = datetime(int(date.split("-")[0]), int(date.split("-")[1]), int(date.split("-")[2]), int(stime.split(":")[0]), int(stime.split(":")[1]),int(stime.split(":")[2])-5)
                                        list_start_time.append(datetime.timestamp(t_start_time))
                                
                                    for etime in args.etime:
                                        t_end_time = datetime(int(date.split("-")[0]), int(date.split("-")[1]), int(date.split("-")[2]), int(etime.split(":")[0]), int(etime.split(":")[1]),int(etime.split(":")[2])+5)
                                        list_end_time.append(datetime.timestamp(t_end_time))

                                if len(list_start_time) != len(list_end_time):
                                    sys.exit(0)

                                # Time validation, is the time read in the interval to be considered?
                                # Monitor time
                                actual_time = datetime.timestamp(actual_date)
                                
                                for j in range(len(list_start_time)):
                                    
                                    if actual_time >= list_start_time[j]:
                                        if actual_time <= list_end_time[j]:
                                            valid_time = True
                                            break
    
                            elif i%2 != 0 and valid_time:
                                valid_time = False
                                value = float(line.split('current=')[1].split(',')[0])
                                dict_files[ff].append(value)

                            i +=1
                        # print(list_start_time)
                        # print(list_end_time)
                        
                        #print(len(dict_files[ff]))
                        # closing file
                        to_read.close()
                        # f.close()
            # Here we have to add the trace on the graph for this directory, which represets the maximum number of iteration
            # Each time we need to add two trace one for pi1, one for pi2

            # Create the lists to compute the mean
            pi1_list = []
            pi2_list = []
            # print(dict_files)
            for key in dict_files.keys():
                if "pi1" in key:
                    # print(len(dict_files[key]))
                    print(len(dict_files[key]))
                    pi1_list.append(dict_files[key].copy())
                else:
                    # print("I think that is pi2")
                    # print(len(dict_files[key]))
                    pi2_list.append(dict_files[key].copy())            
            print(pi1_list)
            print(pi2_list)

            # Creation zips
            zipped_list_pi1 = zip(*pi1_list)
            zipped_list_pi2 = zip(*pi2_list)
            # print("\n\n\n\n")
            # List creation
            list_after_zip_p1 = [np.around(statistics.mean(k), decimals=3) for k in zipped_list_pi1]
            list_after_zip_p2 = [np.around(statistics.mean(k), decimals=3) for k in zipped_list_pi2]
            
            fig_pi1.add_trace(go.Scatter(mode='lines', x=list(range(0,len(list_after_zip_p1))), y=list_after_zip_p1, name=(directory + " iterations")))
            fig_pi2.add_trace(go.Scatter(mode='lines', x=list(range(0,len(list_after_zip_p2))), y=list_after_zip_p2, name=(directory + " iterations")))
        
    fig_pi1.update_layout(title='',
                    xaxis_title='Time',
                    yaxis_title='Temperature(°C)',
                    showlegend=True,)
    fig_pi2.update_layout(title='',
                    xaxis_title='Time',
                    yaxis_title='Temperature(°C)',
                    showlegend=True,)
    
    name = "pi1_temperature_6Round_auto"
    fig_pi1.write_image("./images/" + name + ".pdf")
    name = "pi2_temperature_6Round_auto"
    fig_pi2.write_image("./images/" + name + ".pdf")
    
    fig_pi1.show()
    fig_pi2.show()
    
if __name__ == "__main__":
    args = parser.parse_args()
    main(args)